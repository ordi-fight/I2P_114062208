# from src.core.engine import Engine

# if __name__ == "__main__":
#     engine = Engine()
    
#     engine.run()
# from src.core.engine import Engine

# if __name__ == "__main__":
#     engine = Engine()
#     print("🟢 START ENGINE")
#     engine.run()
from src.core.engine import Engine

print("🟢 1. creating engine")
engine = Engine()
print("🟢 2. running engine")
engine.run()
