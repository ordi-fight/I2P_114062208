from .scene_manager import SceneManager
from .input_manager import InputManager
from .resource_manager import ResourceManager
from .sound_manager import SoundManager
from .game_manager import GameManager
from .online_manager import OnlineManager

# scene_manager.game_manager = game_manager
# game_manager.scene_manager = scene_manager 
# in this time the program haven't start and this only used to say what I WILL HAVE